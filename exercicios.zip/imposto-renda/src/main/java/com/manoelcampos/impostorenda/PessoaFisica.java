package com.manoelcampos.impostorenda;

/**
 * @author Manoel Campos da Silva Filho
 */
public class PessoaFisica extends Pessoa {
    
}
